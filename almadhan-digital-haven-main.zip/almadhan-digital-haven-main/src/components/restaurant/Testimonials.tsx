import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { SectionHeader } from "./SectionHeader";

const reviews = [
  {
    name: { en: "Layla Hassan", ar: "ليلى حسن" },
    role: { en: "Food Critic, Gulf Times", ar: "ناقدة طعام، گلف تايمز" },
    text: {
      en: "An immaculate experience. Al-Madhan elevates Levantine cuisine into pure poetry — the lamb mansaf is, simply, the best in the city.",
      ar: "تجربة لا تُنسى. يرتقي المدهن بالمطبخ الشامي إلى مرتبة الشعر — منسف الخروف ببساطة هو الأفضل في المدينة.",
    },
  },
  {
    name: { en: "Marcus Bennett", ar: "ماركوس بينيت" },
    role: { en: "Hospitality Magazine", ar: "مجلة الضيافة" },
    text: {
      en: "Refined, warm, and deeply rooted in tradition. The interior alone is worth the visit, but the mezze will keep you coming back.",
      ar: "رفيع، دافئ، ومتجذر في التقاليد. التصميم الداخلي وحده يستحق الزيارة، لكن المقبلات ستجعلك تعود مرارًا.",
    },
  },
  {
    name: { en: "Aisha Al-Mansoori", ar: "عائشة المنصوري" },
    role: { en: "Regular Guest", ar: "ضيفة دائمة" },
    text: {
      en: "It feels like coming home. The hospitality, the spices, the music — every detail honors our heritage with grace.",
      ar: "أشعر وكأني في بيتي. الضيافة، التوابل، الموسيقى — كل التفاصيل تُكرّم تراثنا بأناقة.",
    },
  },
];

export function Testimonials() {
  const { t, lang } = useI18n();
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setI((p) => (p + 1) % reviews.length), 6500);
    return () => clearInterval(id);
  }, []);

  const r = reviews[i];

  return (
    <section className="relative py-24 md:py-32 bg-[var(--primary-deep)] overflow-hidden">
      <div className="absolute inset-0 arabesque-bg opacity-15 pointer-events-none" />
      <div className="container relative mx-auto px-6">
        <SectionHeader eyebrow={t("testi_eyebrow")} title={t("testi_title")} light />

        <div className="relative mx-auto max-w-3xl">
          <Quote className="absolute -top-4 left-0 h-16 w-16 text-[var(--gold)]/25 rtl-flip" />
          <AnimatePresence mode="wait">
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-center pt-12"
            >
              <div className="flex justify-center gap-1 mb-6">
                {Array.from({ length: 5 }).map((_, n) => (
                  <Star key={n} className="h-5 w-5 fill-[var(--gold)] text-[var(--gold)]" />
                ))}
              </div>
              <p className="font-display text-2xl md:text-3xl leading-relaxed text-[var(--background)] mb-8 text-balance">
                "{r.text[lang]}"
              </p>
              <div className="text-[var(--gold)] font-semibold">{r.name[lang]}</div>
              <div className="text-sm text-[var(--background)]/60 mt-1">{r.role[lang]}</div>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-center gap-4 mt-10">
            <button
              onClick={() => setI((p) => (p - 1 + reviews.length) % reviews.length)}
              className="grid h-11 w-11 place-items-center rounded-full border border-[var(--gold)]/40 text-[var(--background)] hover:bg-[var(--gold)]/10 transition"
              aria-label="Previous"
            >
              <ChevronLeft className="h-5 w-5 rtl-flip" />
            </button>
            <div className="flex gap-2">
              {reviews.map((_, n) => (
                <button
                  key={n}
                  onClick={() => setI(n)}
                  className={`h-2 rounded-full transition-all ${n === i ? "w-8 bg-[var(--gold)]" : "w-2 bg-[var(--background)]/30"}`}
                  aria-label={`Review ${n + 1}`}
                />
              ))}
            </div>
            <button
              onClick={() => setI((p) => (p + 1) % reviews.length)}
              className="grid h-11 w-11 place-items-center rounded-full border border-[var(--gold)]/40 text-[var(--background)] hover:bg-[var(--gold)]/10 transition"
              aria-label="Next"
            >
              <ChevronRight className="h-5 w-5 rtl-flip" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}