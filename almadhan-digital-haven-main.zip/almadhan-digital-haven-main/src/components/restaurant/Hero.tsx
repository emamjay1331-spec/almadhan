import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Star, MapPin } from "lucide-react";
import heroInterior from "@/assets/real-interior.jpg";
import heroGrill from "@/assets/real-beet.jpg";
import heroMezze from "@/assets/real-mezze.jpg";
import { useI18n } from "@/lib/i18n";

const slides = [heroInterior, heroGrill, heroMezze];

export function Hero() {
  const { t } = useI18n();
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIdx((i) => (i + 1) % slides.length), 5500);
    return () => clearInterval(id);
  }, []);

  return (
    <section id="home" className="relative h-[100svh] min-h-[640px] w-full overflow-hidden">
      <AnimatePresence mode="sync">
        <motion.div
          key={idx}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.4, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <img
            src={slides[idx]}
            alt=""
            className="h-full w-full object-cover animate-ken-burns"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 flex h-full items-center">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.3 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-3 mb-6">
              <span className="h-px w-10 bg-[var(--gold)]" />
              <span className="text-[var(--gold)] uppercase tracking-[0.3em] text-xs font-medium">
                {t("hero_eyebrow")}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3 mb-5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--gold)]/15 backdrop-blur px-3 py-1.5 text-xs font-semibold text-[var(--gold)] border border-[var(--gold)]/40">
                <Star className="h-3.5 w-3.5 fill-[var(--gold)]" /> 4.2
                <span className="text-[var(--background)]/70 font-normal">· 599 reviews</span>
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--background)]/10 backdrop-blur px-3 py-1.5 text-xs font-medium text-[var(--background)]/90 border border-[var(--background)]/20">
                <MapPin className="h-3.5 w-3.5" /> Mall of Arabia · Jeddah
              </span>
            </div>
            <h1 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-balance leading-[1.05] text-[var(--background)] mb-6">
              {t("hero_title")}
            </h1>
            <p className="text-lg md:text-xl text-[var(--background)]/85 max-w-xl mb-10 leading-relaxed">
              {t("hero_subtitle")}
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#reserve"
                className="inline-flex items-center justify-center rounded-full bg-[var(--gold)] px-8 py-4 text-base font-semibold text-[var(--primary-deep)] hover:brightness-110 transition shadow-[var(--shadow-gold)]"
              >
                {t("cta_book")}
              </a>
              <a
                href="#menu"
                className="inline-flex items-center justify-center rounded-full border border-[var(--background)]/40 bg-[var(--background)]/5 backdrop-blur px-8 py-4 text-base font-semibold text-[var(--background)] hover:bg-[var(--background)]/10 transition"
              >
                {t("cta_menu")}
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setIdx(i)}
            aria-label={`Slide ${i + 1}`}
            className={`h-1 rounded-full transition-all ${
              i === idx ? "w-10 bg-[var(--gold)]" : "w-4 bg-[var(--background)]/40"
            }`}
          />
        ))}
      </div>

      <ChevronDown className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 h-6 w-6 text-[var(--background)]/60 animate-bounce" />
    </section>
  );
}