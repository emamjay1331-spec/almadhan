import { motion } from "framer-motion";
import interior from "@/assets/real-interior-2.jpg";
import grill from "@/assets/hero-grill.jpg";
import mezze from "@/assets/hero-mezze.jpg";
import lanterns from "@/assets/gallery-lanterns.jpg";
import chefGrill from "@/assets/gallery-grill.jpg";
import baklava from "@/assets/dish-baklava.jpg";
import tea from "@/assets/dish-tea.jpg";
import { useI18n } from "@/lib/i18n";
import { SectionHeader } from "./SectionHeader";

const images = [
  { src: interior, span: "md:row-span-2" },
  { src: mezze, span: "" },
  { src: baklava, span: "" },
  { src: chefGrill, span: "md:row-span-2" },
  { src: grill, span: "" },
  { src: lanterns, span: "" },
  { src: tea, span: "md:col-span-2" },
];

export function Gallery() {
  const { t } = useI18n();
  return (
    <section id="gallery" className="py-24 md:py-32 bg-[var(--background)]">
      <div className="container mx-auto px-6">
        <SectionHeader eyebrow={t("gallery_eyebrow")} title={t("gallery_title")} />
        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-3 md:gap-4">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: i * 0.06 }}
              className={`group relative overflow-hidden rounded-2xl ${img.span}`}
            >
              <img
                src={img.src}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[var(--primary-deep)]/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}