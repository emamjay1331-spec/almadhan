import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Leaf, Flame, BadgeCheck } from "lucide-react";
import { menuItems, type Category } from "@/lib/menu-data";
import { useI18n } from "@/lib/i18n";
import { SectionHeader } from "./SectionHeader";

const tabs: { key: Category; labelKey: "tab_appetizers" | "tab_mains" | "tab_desserts" | "tab_drinks" }[] = [
  { key: "appetizers", labelKey: "tab_appetizers" },
  { key: "mains", labelKey: "tab_mains" },
  { key: "desserts", labelKey: "tab_desserts" },
  { key: "drinks", labelKey: "tab_drinks" },
];

const dietIcon = {
  halal: BadgeCheck,
  vegan: Leaf,
  spicy: Flame,
};

export function MenuSection() {
  const { t, lang } = useI18n();
  const [active, setActive] = useState<Category>("appetizers");

  const filtered = menuItems.filter((m) => m.category === active);

  return (
    <section id="menu" className="relative py-24 md:py-32 arabesque-bg">
      <div className="container mx-auto px-6">
        <SectionHeader
          eyebrow={t("menu_eyebrow")}
          title={t("menu_title")}
          subtitle={t("menu_subtitle")}
        />

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-12">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActive(tab.key)}
              className={`relative px-5 sm:px-7 py-3 rounded-full text-sm font-semibold transition-all ${
                active === tab.key
                  ? "bg-primary text-[var(--background)] shadow-[var(--shadow-elegant)]"
                  : "bg-[var(--card)] text-[var(--primary-deep)] hover:bg-[var(--muted)]"
              }`}
            >
              {t(tab.labelKey)}
            </button>
          ))}
        </div>

        {/* Items grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            {filtered.map((item, i) => (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.07 }}
                className="group relative overflow-hidden rounded-2xl bg-[var(--card)] shadow-[0_4px_30px_rgba(6,78,59,0.08)] hover:shadow-[var(--shadow-elegant)] transition-all duration-500 hover:-translate-y-1"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name[lang]}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h3 className="font-display text-2xl text-[var(--primary-deep)] leading-tight">
                      {item.name[lang]}
                    </h3>
                  </div>
                  <p className="text-sm text-[var(--muted-foreground)] leading-relaxed mb-4 min-h-[3rem]">
                    {item.description[lang]}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {item.diet.map((d) => {
                      const Icon = dietIcon[d];
                      return (
                        <span
                          key={d}
                          className="inline-flex items-center gap-1 rounded-full bg-[var(--muted)] px-3 py-1 text-xs font-medium text-[var(--primary-deep)]"
                        >
                          <Icon className="h-3 w-3" />
                          {t(d as never)}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </motion.article>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}