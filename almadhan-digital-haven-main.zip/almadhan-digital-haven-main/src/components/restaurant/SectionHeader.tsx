import { motion } from "framer-motion";

export function SectionHeader({
  eyebrow,
  title,
  subtitle,
  light = false,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  light?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7 }}
      className="text-center mb-14 max-w-2xl mx-auto"
    >
      <div className="inline-flex items-center gap-3 mb-4">
        <span className={`h-px w-8 ${light ? "bg-[var(--gold)]" : "bg-[var(--accent)]"}`} />
        <span className={`uppercase tracking-[0.3em] text-xs font-semibold ${light ? "text-[var(--gold)]" : "text-[var(--accent)]"}`}>
          {eyebrow}
        </span>
        <span className={`h-px w-8 ${light ? "bg-[var(--gold)]" : "bg-[var(--accent)]"}`} />
      </div>
      <h2 className={`font-display text-4xl md:text-5xl lg:text-6xl text-balance leading-tight ${light ? "text-[var(--background)]" : "text-[var(--primary-deep)]"}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-base md:text-lg leading-relaxed ${light ? "text-[var(--background)]/80" : "text-[var(--muted-foreground)]"}`}>
          {subtitle}
        </p>
      )}
      <div className="mt-6 arabesque-divider opacity-70" />
    </motion.div>
  );
}