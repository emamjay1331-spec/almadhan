import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Menu, X, Languages } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import logo from "@/assets/logo-almadhan.png";

const sections = [
  { key: "nav_home", href: "#home" },
  { key: "nav_menu", href: "#menu" },
  { key: "nav_reserve", href: "#reserve" },
  { key: "nav_gallery", href: "#gallery" },
  { key: "nav_contact", href: "#contact" },
] as const;

export function Header() {
  const { t, lang, setLang } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "bg-primary/95 backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.15)]"
          : "bg-transparent"
      )}
    >
      <div className="container mx-auto flex h-20 items-center justify-between px-6">
        <a href="#home" className="flex items-center gap-3 group">
          <img
            src={logo}
            alt="Al-Madhan logo"
            className="h-12 w-12 object-contain transition-transform group-hover:rotate-6 drop-shadow-[0_2px_6px_rgba(0,0,0,0.35)]"
          />
          <div className="flex flex-col leading-tight">
            <span className="font-display text-2xl text-[var(--background)] tracking-wide">
              Al-Madhan
            </span>
            <span className="font-arabic text-xs text-[var(--gold)]">مطعم المدهن</span>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {sections.map((s) => (
            <a
              key={s.key}
              href={s.href}
              className="text-sm font-medium text-[var(--background)]/90 hover:text-[var(--gold)] transition-colors relative after:absolute after:bottom-[-6px] after:left-0 after:h-px after:w-0 after:bg-[var(--gold)] after:transition-all hover:after:w-full"
            >
              {t(s.key as never)}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="hidden sm:inline-flex items-center gap-2 rounded-full border border-[var(--gold)]/50 px-4 py-2 text-xs font-semibold text-[var(--background)] hover:bg-[var(--gold)]/15 transition-colors"
            aria-label="Toggle language"
          >
            <Languages className="h-4 w-4" />
            {lang === "en" ? "AR" : "EN"}
          </button>
          <a
            href="#reserve"
            className="hidden md:inline-flex items-center justify-center rounded-full bg-[var(--gold)] px-6 py-2.5 text-sm font-semibold text-[var(--primary-deep)] hover:brightness-110 transition shadow-[var(--shadow-gold)]"
          >
            {t("cta_book")}
          </a>
          <button
            onClick={() => setOpen((o) => !o)}
            className="lg:hidden text-[var(--background)] p-2"
            aria-label="Menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-primary/98 backdrop-blur-md border-t border-[var(--gold)]/20">
          <div className="container mx-auto flex flex-col gap-1 px-6 py-4">
            {sections.map((s) => (
              <a
                key={s.key}
                href={s.href}
                onClick={() => setOpen(false)}
                className="py-3 text-[var(--background)] hover:text-[var(--gold)]"
              >
                {t(s.key as never)}
              </a>
            ))}
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="mt-2 inline-flex items-center gap-2 self-start rounded-full border border-[var(--gold)]/50 px-4 py-2 text-xs font-semibold text-[var(--background)]"
            >
              <Languages className="h-4 w-4" />
              {lang === "en" ? "العربية" : "English"}
            </button>
          </div>
        </div>
      )}
    </motion.header>
  );
}