import { Instagram, Facebook, Twitter } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import logo from "@/assets/logo-almadhan.png";

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="bg-[var(--primary-deep)] text-[var(--background)]/80 py-14">
      <div className="container mx-auto px-6">
        <div className="grid gap-10 md:grid-cols-3 items-start">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logo} alt="Al-Madhan logo" className="h-12 w-12 object-contain" />
              <div className="leading-tight">
                <div className="font-display text-2xl text-[var(--background)]">Al-Madhan</div>
                <div className="font-arabic text-xs text-[var(--gold)]">مطعم المدهن</div>
              </div>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">{t("footer_tagline")}</p>
          </div>

          <div className="flex flex-col gap-2 text-sm">
            <a href="#menu" className="hover:text-[var(--gold)] transition-colors">{t("nav_menu")}</a>
            <a href="#reserve" className="hover:text-[var(--gold)] transition-colors">{t("nav_reserve")}</a>
            <a href="#gallery" className="hover:text-[var(--gold)] transition-colors">{t("nav_gallery")}</a>
            <a href="#contact" className="hover:text-[var(--gold)] transition-colors">{t("nav_contact")}</a>
          </div>

          <div>
            <div className="font-display text-lg text-[var(--background)] mb-4">Follow</div>
            <div className="flex gap-3">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="social"
                  className="grid h-10 w-10 place-items-center rounded-full border border-[var(--gold)]/30 hover:bg-[var(--gold)]/10 hover:text-[var(--gold)] transition"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="arabesque-divider opacity-50 my-8" />
        <div className="text-xs text-center text-[var(--background)]/50">
          © {new Date().getFullYear()} Al-Madhan · {t("rights")}
        </div>
      </div>
    </footer>
  );
}