import { useState } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { CalendarIcon, Users, Clock } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";
import { SectionHeader } from "./SectionHeader";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().trim().min(6).max(30),
  email: z.string().trim().email().max(120),
  date: z.date(),
  time: z.string().min(1),
  party: z.string().min(1),
  occasion: z.string().max(300).optional(),
});

const times = [
  "12:00", "12:30", "13:00", "13:30", "18:00", "18:30",
  "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
];

export function ReservationSection() {
  const { t } = useI18n();
  const [date, setDate] = useState<Date | undefined>();
  const [time, setTime] = useState("");
  const [party, setParty] = useState("2");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [occasion, setOccasion] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse({ name, phone, email, date, time, party, occasion });
    if (!result.success) {
      toast.error(result.error.issues[0]?.message ?? "Please complete the form.");
      return;
    }
    toast.success(t("reservation_success"));
    setName(""); setPhone(""); setEmail(""); setDate(undefined); setTime(""); setParty("2"); setOccasion("");
  };

  return (
    <section
      id="reserve"
      className="relative py-24 md:py-32 overflow-hidden"
      style={{ background: "var(--gradient-emerald)" }}
    >
      <div className="absolute inset-0 arabesque-bg opacity-20 pointer-events-none" />
      <div className="container relative mx-auto px-6">
        <SectionHeader
          eyebrow={t("reserve_eyebrow")}
          title={t("reserve_title")}
          subtitle={t("reserve_subtitle")}
          light
        />

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-3xl rounded-3xl bg-[var(--background)] p-8 md:p-12 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.5)]"
        >
          <div className="grid gap-5 md:grid-cols-2">
            <Field label={t("name")}>
              <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} />
            </Field>
            <Field label={t("phone")}>
              <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required maxLength={30} />
            </Field>
            <div className="md:col-span-2">
              <Field label={t("email")}>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={120} />
              </Field>
            </div>

            <Field label={t("date")}>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-start font-normal h-11",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="me-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>{t("pick_date")}</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={(d) => d < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </Field>

            <Field label={t("time")}>
              <Select value={time} onValueChange={setTime}>
                <SelectTrigger className="h-11">
                  <Clock className="me-2 h-4 w-4 opacity-60" />
                  <SelectValue placeholder="--:--" />
                </SelectTrigger>
                <SelectContent>
                  {times.map((tm) => (
                    <SelectItem key={tm} value={tm}>{tm}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <div className="md:col-span-2">
              <Field label={t("party_size")}>
                <Select value={party} onValueChange={setParty}>
                  <SelectTrigger className="h-11">
                    <Users className="me-2 h-4 w-4 opacity-60" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1,2,3,4,5,6,7,8,10,12].map((n) => (
                      <SelectItem key={n} value={String(n)}>
                        {n} {t("guests")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </div>

            <div className="md:col-span-2">
              <Field label={t("occasion")}>
                <Textarea
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  placeholder={t("occasion_placeholder")}
                  maxLength={300}
                  rows={3}
                />
              </Field>
            </div>
          </div>

          <button
            type="submit"
            className="mt-8 w-full rounded-full bg-[var(--accent)] py-4 text-base font-semibold text-[var(--primary-deep)] hover:brightness-110 transition shadow-[var(--shadow-gold)]"
          >
            {t("confirm_reservation")}
          </button>
        </motion.form>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-[var(--primary-deep)]">{label}</Label>
      {children}
    </div>
  );
}