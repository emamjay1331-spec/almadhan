import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Mail } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { SectionHeader } from "./SectionHeader";

export function Contact() {
  const { t } = useI18n();
  return (
    <section id="contact" className="py-24 md:py-32 bg-[var(--background)]">
      <div className="container mx-auto px-6">
        <SectionHeader eyebrow={t("contact_eyebrow")} title={t("contact_title")} />

        <div className="grid gap-8 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <InfoCard icon={MapPin} title="مطعم المدهن · Al-Madhan Restaurant">
              <p className="text-[var(--muted-foreground)]">{t("address")}</p>
              <p className="text-xs text-[var(--muted-foreground)]/80 mt-1">
                Located in: Cenomi Mall of Arabia · Plus Code: J5J4+XC, An Nuzhah
              </p>
            </InfoCard>

            <InfoCard icon={Phone} title={t("call_us")}>
              <a
                href="tel:+966544933424"
                className="text-lg font-semibold text-[var(--primary)] hover:text-[var(--accent)] transition-colors"
              >
                +966 54 493 3424
              </a>
            </InfoCard>

            <InfoCard icon={Mail} title="Email">
              <a
                href="mailto:hello@al-madhan.com"
                className="text-[var(--primary)] hover:text-[var(--accent)] transition-colors"
              >
                hello@al-madhan.com
              </a>
            </InfoCard>

            <InfoCard icon={Clock} title={t("hours_title")}>
              <ul className="space-y-1.5 text-sm text-[var(--muted-foreground)]">
                <li>{t("hours_weekdays")}</li>
                <li className="text-[var(--accent)] font-medium">{t("hours_friday")}</li>
                <li className="italic">{t("hours_break")}</li>
              </ul>
            </InfoCard>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative overflow-hidden rounded-3xl shadow-[var(--shadow-elegant)] min-h-[420px] bg-[var(--muted)]"
          >
            <iframe
              title="Al-Madhan Location"
              src="https://maps.google.com/maps?q=Mall%20of%20Arabia%20Jeddah%20Al%20Fayhaa&t=&z=15&ie=UTF8&iwloc=&output=embed"
              loading="lazy"
              className="absolute inset-0 h-full w-full grayscale-[20%] saturate-150"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function InfoCard({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex gap-5 rounded-2xl bg-[var(--card)] p-6 shadow-[0_4px_20px_rgba(6,78,59,0.06)] hover:shadow-[var(--shadow-elegant)] transition-shadow">
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-[var(--primary)]/10 text-[var(--primary)]">
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <h3 className="font-display text-xl text-[var(--primary-deep)] mb-2">{title}</h3>
        {children}
      </div>
    </div>
  );
}