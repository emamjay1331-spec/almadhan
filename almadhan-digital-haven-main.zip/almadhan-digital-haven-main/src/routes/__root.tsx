import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { I18nProvider } from "@/lib/i18n";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Al-Madhan · Best Arabic Restaurant & Fine Dining Middle Eastern Food" },
      { name: "description", content: "Al-Madhan (المدهن) — sophisticated Arabian fine dining. Slow-grilled meats, mezze, and timeless hospitality. Reserve your table tonight." },
      { name: "keywords", content: "Best Arabic Restaurant, Fine Dining Middle Eastern Food, Levantine cuisine, halal restaurant, mansaf, mezze, shawarma" },
      { name: "author", content: "Al-Madhan" },
      { property: "og:title", content: "Al-Madhan · Best Arabic Restaurant & Fine Dining Middle Eastern Food" },
      { property: "og:description", content: "Al-Madhan (المدهن) — sophisticated Arabian fine dining. Slow-grilled meats, mezze, and timeless hospitality. Reserve your table tonight." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@AlMadhan" },
      { name: "twitter:title", content: "Al-Madhan · Best Arabic Restaurant & Fine Dining Middle Eastern Food" },
      { name: "twitter:description", content: "Al-Madhan (المدهن) — sophisticated Arabian fine dining. Slow-grilled meats, mezze, and timeless hospitality. Reserve your table tonight." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/490792e1-b247-4d27-8067-a8ae5db8c2ef/id-preview-81986035--cda8a567-5168-4368-9937-40642d904a78.lovable.app-1777189020495.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/490792e1-b247-4d27-8067-a8ae5db8c2ef/id-preview-81986035--cda8a567-5168-4368-9937-40642d904a78.lovable.app-1777189020495.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <I18nProvider>
      <Outlet />
      <Toaster richColors position="top-center" />
    </I18nProvider>
  );
}
