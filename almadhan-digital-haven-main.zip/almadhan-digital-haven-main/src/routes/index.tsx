import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/restaurant/Header";
import { Hero } from "@/components/restaurant/Hero";
import { MenuSection } from "@/components/restaurant/MenuSection";
import { ReservationSection } from "@/components/restaurant/ReservationSection";
import { Gallery } from "@/components/restaurant/Gallery";
import { Testimonials } from "@/components/restaurant/Testimonials";
import { Contact } from "@/components/restaurant/Contact";
import { Footer } from "@/components/restaurant/Footer";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-[var(--background)]">
      <Header />
      <main>
        <Hero />
        <MenuSection />
        <ReservationSection />
        <Gallery />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
