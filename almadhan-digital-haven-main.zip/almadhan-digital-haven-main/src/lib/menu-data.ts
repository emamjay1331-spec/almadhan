import hummus from "@/assets/dish-hummus.jpg";
import shawarma from "@/assets/dish-shawarma.jpg";
import mixedGrillReal from "@/assets/real-mixed-grill.jpg";
import tabbouleh from "@/assets/dish-tabbouleh.jpg";
import baklava from "@/assets/dish-baklava.jpg";
import mansaf from "@/assets/dish-mansaf.jpg";
import tea from "@/assets/dish-tea.jpg";
import falafel from "@/assets/dish-falafel.jpg";

export type Diet = "halal" | "vegan" | "spicy";
export type Category = "appetizers" | "mains" | "desserts" | "drinks";

export type MenuItem = {
  id: string;
  category: Category;
  name: { en: string; ar: string };
  description: { en: string; ar: string };
  price: number;
  image: string;
  diet: Diet[];
};

export const menuItems: MenuItem[] = [
  {
    id: "hummus",
    category: "appetizers",
    name: { en: "Hummus Beiruti", ar: "حمص بيروتي" },
    description: {
      en: "Silky chickpea purée, tahini, lemon, topped with warm pine nuts and olive oil.",
      ar: "حمص حريري مع طحينة وليمون، مزيّن بصنوبر دافئ وزيت زيتون.",
    },
    price: 14,
    image: hummus,
    diet: ["halal", "vegan"],
  },
  {
    id: "falafel",
    category: "appetizers",
    name: { en: "Crispy Falafel", ar: "فلافل مقرمشة" },
    description: {
      en: "Hand-rolled chickpea fritters, herbs, served with house tahini.",
      ar: "أقراص حمص بالأعشاب، تُقدّم مع طحينة البيت.",
    },
    price: 12,
    image: falafel,
    diet: ["halal", "vegan"],
  },
  {
    id: "tabbouleh",
    category: "appetizers",
    name: { en: "Tabbouleh", ar: "تبولة" },
    description: {
      en: "Fresh parsley, bulgur, vine-ripened tomatoes, lemon and mint.",
      ar: "بقدونس طازج، برغل، طماطم ناضجة، ليمون ونعناع.",
    },
    price: 11,
    image: tabbouleh,
    diet: ["halal", "vegan"],
  },
  {
    id: "mansaf",
    category: "mains",
    name: { en: "Mansaf Royale", ar: "منسف ملوكي" },
    description: {
      en: "Slow-braised lamb shank, jameed yogurt sauce, saffron rice, toasted almonds.",
      ar: "ساق خروف مطهو ببطء، صلصة جميد، أرز بالزعفران ولوز محمّص.",
    },
    price: 42,
    image: mansaf,
    diet: ["halal"],
  },
  {
    id: "shawarma",
    category: "mains",
    name: { en: "Lamb Shawarma Plate", ar: "صحن شاورما لحم" },
    description: {
      en: "Spit-roasted lamb shavings, garlic toum, pickles, warm pita.",
      ar: "شرائح شاورما لحم، ثوم، مخللات، خبز عربي دافئ.",
    },
    price: 32,
    image: shawarma,
    diet: ["halal", "spicy"],
  },
  {
    id: "mixed-grill",
    category: "mains",
    name: { en: "Al-Madhan Mixed Grill", ar: "مشاوي المدهن المشكلة" },
    description: {
      en: "Lamb kofta, shish tawook, beef kebab, grilled vegetables, saffron rice.",
      ar: "كفتة لحم، شيش طاووق، كباب لحم، خضار مشوية، أرز بالزعفران.",
    },
    price: 48,
    image: mixedGrillReal,
    diet: ["halal", "spicy"],
  },
  {
    id: "baklava",
    category: "desserts",
    name: { en: "Pistachio Baklava", ar: "بقلاوة بالفستق" },
    description: {
      en: "Layers of golden filo, Aleppo pistachios, orange-blossom syrup.",
      ar: "طبقات عجين ذهبية، فستق حلبي، قطر بماء الزهر.",
    },
    price: 14,
    image: baklava,
    diet: ["halal"],
  },
  {
    id: "kunafa",
    category: "desserts",
    name: { en: "Knafeh Nabulsiyeh", ar: "كنافة نابلسية" },
    description: {
      en: "Warm semolina pastry, melted akkawi cheese, pistachios, rose syrup.",
      ar: "كنافة دافئة، جبنة عكاوي ذائبة، فستق وقطر بماء الورد.",
    },
    price: 16,
    image: baklava,
    diet: ["halal"],
  },
  {
    id: "mint-tea",
    category: "drinks",
    name: { en: "Adani Tea", ar: "شاي عدني" },
    description: {
      en: "Gunpowder green tea, fresh mint, poured from height.",
      ar: "شاي أخضر بارود مع نعناع طازج يُسكب من علوّ.",
    },
    price: 8,
    image: tea,
    diet: ["halal", "vegan"],
  },
  {
    id: "arabic-coffee",
    category: "drinks",
    name: { en: "Black Tea", ar: "شاي أسود" },
    description: {
      en: "Classic full-bodied black tea, freshly brewed.",
      ar: "شاي أسود تقليدي غني النكهة، يُحضّر طازجًا.",
    },
    price: 7,
    image: tea,
    diet: ["halal", "vegan"],
  },
];