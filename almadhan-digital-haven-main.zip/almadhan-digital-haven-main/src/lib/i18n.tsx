import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ar";

type Dict = Record<string, string>;

const translations: Record<Lang, Dict> = {
  en: {
    nav_home: "Home",
    nav_menu: "Menu",
    nav_reserve: "Reserve",
    nav_gallery: "Gallery",
    nav_about: "About",
    nav_contact: "Contact",
    cta_book: "Book a Table",
    cta_menu: "View Menu",
    hero_eyebrow: "Authentic Arabian Cuisine",
    hero_title: "A Feast for the Senses",
    hero_subtitle: "Experience the warmth of the Levant — slow-grilled meats, ancient spices, and timeless hospitality.",
    menu_eyebrow: "Our Menu",
    menu_title: "Crafted with Tradition",
    menu_subtitle: "Each dish tells a story, passed through generations and prepared with the finest ingredients.",
    tab_appetizers: "Appetizers",
    tab_mains: "Main Course",
    tab_desserts: "Desserts",
    tab_drinks: "Drinks",
    halal: "Halal",
    vegan: "Vegan",
    spicy: "Spicy",
    reserve_eyebrow: "Reservations",
    reserve_title: "Reserve Your Table",
    reserve_subtitle: "Join us for an unforgettable evening. Book your table in just a few moments.",
    name: "Full Name",
    phone: "Phone Number",
    email: "Email",
    date: "Date",
    time: "Time",
    party_size: "Party Size",
    guests: "Guests",
    occasion: "Special Occasion",
    occasion_placeholder: "Birthday, anniversary, dietary needs…",
    confirm_reservation: "Confirm Reservation",
    pick_date: "Pick a date",
    gallery_eyebrow: "Gallery",
    gallery_title: "A Glimpse of Al-Madhan",
    contact_eyebrow: "Visit Us",
    contact_title: "Find Your Way Home",
    address: "Cenomi Mall of Arabia, Al Fayhaa, Jeddah 23532, Saudi Arabia",
    hours_title: "Opening Hours",
    hours_weekdays: "Daily: 12:00 PM – 12:00 AM",
    hours_friday: "Friday: Closed for Jumu'ah · Reopens 2:00 PM",
    hours_break: "Daily prayer breaks observed",
    call_us: "Call Us",
    testi_eyebrow: "Testimonials",
    testi_title: "Loved by Our Guests",
    footer_tagline: "Where every meal is a celebration of heritage.",
    rights: "All rights reserved.",
    reservation_success: "Reservation request received! We'll confirm shortly.",
  },
  ar: {
    nav_home: "الرئيسية",
    nav_menu: "القائمة",
    nav_reserve: "احجز",
    nav_gallery: "المعرض",
    nav_about: "من نحن",
    nav_contact: "اتصل بنا",
    cta_book: "احجز طاولة",
    cta_menu: "تصفح القائمة",
    hero_eyebrow: "مطبخ عربي أصيل",
    hero_title: "مأدبة للحواس",
    hero_subtitle: "اختبر دفء بلاد الشام — لحوم مشوية ببطء، توابل عريقة، وكرم ضيافة لا يُنسى.",
    menu_eyebrow: "قائمتنا",
    menu_title: "صُنعت بحب التقاليد",
    menu_subtitle: "كل طبق يروي قصة، تتوارثها الأجيال وتُعدّ من أجود المكونات.",
    tab_appetizers: "المقبلات",
    tab_mains: "الأطباق الرئيسية",
    tab_desserts: "الحلويات",
    tab_drinks: "المشروبات",
    halal: "حلال",
    vegan: "نباتي",
    spicy: "حار",
    reserve_eyebrow: "الحجوزات",
    reserve_title: "احجز طاولتك",
    reserve_subtitle: "انضم إلينا لأمسية لا تُنسى. احجز طاولتك خلال لحظات.",
    name: "الاسم الكامل",
    phone: "رقم الهاتف",
    email: "البريد الإلكتروني",
    date: "التاريخ",
    time: "الوقت",
    party_size: "عدد الأشخاص",
    guests: "ضيوف",
    occasion: "مناسبة خاصة",
    occasion_placeholder: "عيد ميلاد، ذكرى زواج، احتياجات غذائية…",
    confirm_reservation: "تأكيد الحجز",
    pick_date: "اختر التاريخ",
    gallery_eyebrow: "المعرض",
    gallery_title: "لمحة من المدهن",
    contact_eyebrow: "زرنا",
    contact_title: "طريقك إلى البيت",
    address: "سينومي العرب مول، الفيحاء، جدة 23532، المملكة العربية السعودية",
    hours_title: "ساعات العمل",
    hours_weekdays: "يوميًا: ١٢:٠٠ ظهرًا – ١٢:٠٠ منتصف الليل",
    hours_friday: "الجمعة: مغلق لصلاة الجمعة · يُعاد الفتح ٢:٠٠ مساءً",
    hours_break: "نراعي أوقات الصلاة اليومية",
    call_us: "اتصل بنا",
    testi_eyebrow: "آراء الضيوف",
    testi_title: "محبوبون لدى ضيوفنا",
    footer_tagline: "حيث تتحول كل وجبة إلى احتفال بالتراث.",
    rights: "جميع الحقوق محفوظة.",
    reservation_success: "تم استلام طلب الحجز! سنؤكد قريبًا.",
  },
};

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: keyof typeof translations.en) => string;
  dir: "ltr" | "rtl";
};

const I18nContext = createContext<Ctx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");

  useEffect(() => {
    const dir = lang === "ar" ? "rtl" : "ltr";
    document.documentElement.setAttribute("dir", dir);
    document.documentElement.setAttribute("lang", lang);
  }, [lang]);

  const value: Ctx = {
    lang,
    setLang,
    t: (key) => translations[lang][key] ?? String(key),
    dir: lang === "ar" ? "rtl" : "ltr",
  };

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}